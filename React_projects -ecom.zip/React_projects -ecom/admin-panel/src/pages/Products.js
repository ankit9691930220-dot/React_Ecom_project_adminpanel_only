import { useEffect, useState } from "react";
import api from "../services/api";
import { toast } from "react-toastify";
import ProductForm from "../components/ProductForm";

function Products() {
  const [products, setProducts] = useState([]);
  const [editingProduct, setEditingProduct] = useState(null);
  const [showForm, setShowForm] = useState(false);

  // Fetch products
  const fetchProducts = () => {
    api.get("/products")
      .then(res => setProducts(res.data))
      .catch(() => toast.error("Failed to fetch products"));
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  // Delete product
  const deleteProduct = (id) => {
    api.delete(`/products/${id}`)
      .then(() => {
        toast.success("Product deleted!");
        setProducts(products.filter(p => p.id !== id));
      })
      .catch(() => toast.error("Delete failed"));
  };

  return (
    <div className="row">
      <div className="col-md-4">
        {/* <ProductForm
          selectedProduct={editingProduct}
          onSuccess={() => {
            fetchProducts();
            setEditingProduct(null); // reset form
          }}
        /> */}
        {showForm && (
        <div className="mb-4">
          <ProductForm
            selectedProduct={editingProduct}
            onSuccess={() => {
              fetchProducts();
              setEditingProduct(null);
              setShowForm(false);

            }}
            onClose={() => {
                setEditingProduct(null);
                setShowForm(false);
            }}
          />
        </div>
      )}
      </div>

      <div className="col-md-8">
        <h2>Product List</h2>
        <div className="pull-right">
             <button
                className="btn btn-primary"
                onClick={() => {
                setEditingProduct(null); // new product
                setShowForm(true);
                    }}>
                     + Add Product
                 </button>
                 
        </div>
        <table className="table table-bordered">
          <thead>
            <tr>
              <th>#</th><th>Name</th><th>Price</th><th>Stock</th><th>Action</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p, i) => (
              <tr key={p.id}>
                <td>{i+1}</td>
                <td>{p.name}</td>
                <td>${p.price}</td>
                <td>{p.stock}</td>
                <td>
                  <button
                    className="btn btn-sm btn-warning me-2"
                    onClick={() => {setEditingProduct(p);
                        setShowForm(true);
                    }}
                  >
                    Edit
                  </button>
                  <button
                    className="btn btn-sm btn-danger"
                    onClick={() => deleteProduct(p.id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
export default Products;
