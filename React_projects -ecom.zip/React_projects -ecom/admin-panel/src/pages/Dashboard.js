import { useEffect, useState } from "react";
import api from "../services/api";
import { toast } from "react-toastify";

function Dashboard() {
  const [products, setProducts] = useState([]);


  return (
    <div>
      <h2>Dashboard</h2>
      
    </div>
  );
}
export default Dashboard;
