import { useEffect, useState } from "react";
import api from "../services/api";
import { toast } from "react-toastify";

function Categories() {
  const [products, setProducts] = useState([]);

  // Product fetch
  useEffect(() => {
    api.get("/products")
      .then(res => setProducts(res.data))
      .catch(() => toast.error("Failed to fetch products"));
  }, []);

  // Delete Product
  const deleteProduct = (id) => {
    api.delete(`/products/${id}`)
      .then(() => {
        toast.success("Product deleted!");
        setProducts(products.filter(p => p.id !== id));
      })
      .catch(() => toast.error("Delete failed"));
  };

  return (
    <div>
      <h2>Products</h2>
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>#</th><th>Name</th><th>Price</th><th>Action</th>
          </tr>
        </thead>
        <tbody>
          {products.map((p, i) => (
            <tr key={p.id}>
              <td>{i+1}</td>
              <td>{p.name}</td>
              <td>${p.price}</td>
              <td>
                <button className="btn btn-danger btn-sm" onClick={() => deleteProduct(p.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
export default Categories;
