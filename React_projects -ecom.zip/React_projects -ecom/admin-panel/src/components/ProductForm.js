import { useState, useEffect } from "react";
import api from "../services/api";
import { toast } from "react-toastify";

function ProductForm({ selectedProduct, onSuccess, onClose}) {
  const [formData, setFormData] = useState({
    name: "",
    price: "",
    stock: "",
  });

  // Agar edit ho to existing data load karo
  useEffect(() => {
    if (selectedProduct) {
      setFormData({
        name: selectedProduct.name,
        price: selectedProduct.price,
        stock: selectedProduct.stock,
      });
    }
  }, [selectedProduct]);

  // Input change handler
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  // Submit handler (Add/Edit dono ke liye)
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (selectedProduct) {
        // Update API
        await api.put(`/products/${selectedProduct.id}`, formData);
        toast.success("Product updated successfully!");
      } else {
        // Add API
        await api.post("/products", formData);
        toast.success("Product added successfully!");
      }
      onSuccess(); // refresh parent list
      setFormData({ name: "", price: "", stock: "" });
    } catch (error) {
      toast.error("Error while saving product");
    }
  };

  return (

    <form onSubmit={handleSubmit} className="card p-3 shadow-sm">
      <h4>{selectedProduct ? "Edit Product" : "Add Product"}</h4>

 <div className="d-flex justify-content-between align-items-center mb-3">
        <h4 className="m-0">
          {selectedProduct ? "Edit Product" : "Add Product"}
        </h4>
        <button
          type="button"
          className="btn btn-sm btn-secondary"
          onClick={onClose}
        >
          ✖ Close
        </button>
      </div>

      <div className="mb-3">
        <label className="form-label">Name</label>
        <input
          type="text"
          name="name"
          className="form-control"
          value={formData.name}
          onChange={handleChange}
          required
        />
      </div>

      <div className="mb-3">
        <label className="form-label">Price</label>
        <input
          type="number"
          name="price"
          className="form-control"
          value={formData.price}
          onChange={handleChange}
          required
        />
      </div>

      <div className="mb-3">
        <label className="form-label">Stock</label>
        <input
          type="number"
          name="stock"
          className="form-control"
          value={formData.stock}
          onChange={handleChange}
          required
        />
      </div>

      <button type="submit" className="btn btn-primary">
        {selectedProduct ? "Update" : "Add"}
      </button>
      
    </form>
  );
}

export default ProductForm;
