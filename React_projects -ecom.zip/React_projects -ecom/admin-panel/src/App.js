import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-toastify/dist/ReactToastify.css';
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import Dashboard from "./pages/Dashboard";
import Products from "./pages/Products";
function App() {
  return (
    <Router>
      <div className="container-fluid">
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
          <Link to="/" className="navbar-brand">Admin Panel</Link>
          <div className="navbar-nav">
            <Link to="/" className="nav-link">Dashboard</Link>
            <Link to="/products" className="nav-link">Products</Link>
           
          </div>
        </nav>

        <div className="p-4">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/products" element={<Products />} />
              </Routes>
        </div>
      </div>
      <ToastContainer />
    </Router>
  );
}

export default App;
